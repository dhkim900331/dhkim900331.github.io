document.addEventListener('paste', function (evt) {
	// 붙여넣기를 할 때, 클립보드 데이터를 clipdata 변수로
	clipdata = evt.clipboardData || window.clipboardData;
	
	// html 을 파싱하기 위한 DOMParser
	const parser = new DOMParser();
	
	// clipdata를 'text/html' 형식으로
	const htmlStr = clipdata.getData('text/html');
		
	// clipdata를 Parser로 가공하기 위해 변환 작업
	const do2 = parser.parseFromString(htmlStr, "text/html");
	
	// 제목
	var title = do2.querySelector("h2.hP").innerText;
	//console.log("제목 : " + title);
	
	// 보낸사람
	var fromEmail = do2.querySelector(".acZ").querySelector(".gD").getAttribute("email");
	var fromName = do2.querySelector(".acZ").querySelector(".gD").getAttribute("name");
	//console.log("보낸사람 : " + fromName + "(" + fromEmail +")");
	
	// 받는사람
	var toArray = do2.querySelector("div.iw").querySelectorAll("span.g2");
	var toInfo = "보낸사람 : ";
	Array.from(toArray).forEach(function(el) {
		toInfo += el.getAttribute("email") + "(" + el.getAttribute("name") + ") ";
	});
	//console.log(toInfo);
	
	// 시간
	var date = do2.querySelector("span.g3").getAttribute("title");
	//console.log("일자 : " + date);
	
	// 숨은참조
	
	
	// 내용
	var content = do2.querySelector("div.a3s").querySelector("div").innerHTML;
	//console.log(content);
	
	var data = '';
	data += `제목: ${title} <br>\n`;
	data += `보낸사람: ${fromName} (${fromEmail}) <br>\n`;
	data += `받는사람: ${toInfo} <br>\n`;
	data += `받은시각: ${date} <br>\n`;
	data += `##### 내용 ##### <br>\n`;
	data += `${content} <br>\n`;
	console.log(data);
});